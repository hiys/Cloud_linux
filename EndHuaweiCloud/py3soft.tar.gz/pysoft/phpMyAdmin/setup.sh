#!/bin/bash

rm -f /etc/yum.repos.d/*.repo
cp CentOS7-Base-163.repo /etc/yum.repos.d/
yum install -y httpd php php-mysql php-mbstring
retval=$?

if [ $retval -ne 0 ]; then
    echo "安装软件包失败，请检查互联网连接"
    exit 1
fi

systemctl start httpd
systemctl enable httpd
tar xzf phpMyAdmin-4.0.10.20-all-languages.tar.gz
mv phpMyAdmin-4.0.10.20-all-languages /var/www/html/phpmyadmin/
echo "请通过浏览器访问http://127.0.0.1/phpmyadmin"
